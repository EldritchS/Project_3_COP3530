#include "Algorithms.h"
namespace routebench {
SearchResult dijkstra(const AdjacencyList& graph, int source, int target) {
    return runBestFirst(graph, source, target, false);
}
}  // namespace routebench
