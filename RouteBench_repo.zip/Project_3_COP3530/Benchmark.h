#pragma once
#include "Algorithms.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace routebench {

struct Query {
    int source = -1;
    int target = -1;
    bool expected_unreachable = false;
};

struct BenchmarkSummary {
    std::size_t queries = 0;
    std::size_t unreachable_queries = 0;
    double dijkstra_mean_expanded = 0;
    double astar_mean_expanded = 0;
    double dijkstra_mean_median_ms = 0;
    double astar_mean_median_ms = 0;
};

std::vector<Query> makeQueries(const AdjacencyList& graph, std::size_t count,
                               std::uint32_t seed = 3530);
BenchmarkSummary benchmark(const AdjacencyList& graph, const std::vector<Query>& queries,
                           std::size_t repeats, const std::string& csv_filename);

}  // namespace routebench
