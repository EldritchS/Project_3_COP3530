#include "AdjacencyList.h"
#include "Algorithms.h"
#include "Benchmark.h"

#include <chrono>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
using namespace routebench;

std::int64_t readId(const std::string& message) {
    std::cout << message;
    std::string line;
    if (!std::getline(std::cin, line)) throw std::runtime_error("Input ended");
    std::size_t consumed = 0;
    const auto id = std::stoll(line, &consumed);
    if (consumed != line.size()) throw std::invalid_argument("Enter a numeric vertex ID");
    return id;
}

void showStats(const AdjacencyList& g) {
    auto stats = g.validate();
    std::cout << "Loaded " << stats.vertices << " vertices, " << stats.edges << " directed edges\n"
              << "Self-loops: " << stats.self_loops
              << "; parallel directed edges: " << stats.parallel_directed_edges << "\n"
              << "Edges shorter than great-circle distance: " << stats.edges_shorter_than_great_circle
              << " (A* heuristic scale c = " << std::setprecision(6) << stats.heuristic_scale << ")\n"
              << "Florida bounding-box check: PASS\n"
              << "100,000-vertex project target: "
              << (stats.meets_size_target ? "MET" : "NOT MET (small/demo dataset)") << "\n";
}

// Runs one search and reports its wall-clock time; graph loading is never inside the timer.
SearchResult timedSearch(const AdjacencyList& g, bool use_astar, int src, int dst, double& ms) {
    const auto start = std::chrono::steady_clock::now();
    SearchResult result = use_astar ? astar(g, src, dst) : dijkstra(g, src, dst);
    const auto end = std::chrono::steady_clock::now();
    ms = std::chrono::duration<double, std::milli>(end - start).count();
    return result;
}

void printResult(const AdjacencyList& g, const char* name, const SearchResult& r,
                 int src, int dst, double ms) {
    std::cout << name << ": ";
    if (!r.reachable) { std::cout << "unreachable"; }
    else {
        std::cout << std::fixed << std::setprecision(3) << r.distance_m << " m; "
                  << r.hops() << " hops; path ";
        for (std::size_t i = 0; i < r.path.size(); ++i) {
            if (i) std::cout << " -> ";
            if (i >= 12 && i + 2 < r.path.size()) {
                std::cout << "... (" << r.path.size() - i - 2 << " more vertices) ...";
                i = r.path.size() - 3;
                continue;
            }
            std::cout << g.vertex(r.path[i]).external_id;
        }
    }
    std::cout << "; expanded " << r.expanded << " vertices; time "
              << std::fixed << std::setprecision(3) << ms << " ms"
              << "; path valid " << (validatePath(g, src, dst, r) ? "YES" : "NO") << '\n';
}

void menu() {
    std::cout << "\nROUTEBENCH | Florida road-network shortest paths\n"
              << "1. Load graph CSV files\n"
              << "2. Set source vertex ID\n"
              << "3. Set destination vertex ID\n"
              << "4. Run Dijkstra\n"
              << "5. Run A*\n"
              << "6. Compare both\n"
              << "7. Benchmark random queries to CSV\n"
              << "8. Print history\n"
              << "9. Exit\nChoice: ";
}

std::size_t parsePositive(const std::string& option, const std::string& value) {
    std::size_t used = 0;
    unsigned long long parsed = 0;
    if (value.empty() || value[0] == '-' || value[0] == '+')
        throw std::invalid_argument(option + " needs a positive whole number");
    try {
        parsed = std::stoull(value, &used);
    } catch (const std::exception&) {
        throw std::invalid_argument(option + " needs a positive whole number");
    }
    if (used != value.size() || parsed == 0)
        throw std::invalid_argument(option + " needs a positive whole number");
    return static_cast<std::size_t>(parsed);
}

void intro() {
    std::cout << "________________________________________\n"
              << "Welcome to our distance calculator.\n"
              << "Not a GPS, but good to plan around.\n"
              << "Made to compare A* and Dijkstra's algs.\n"
              << "________________________________________\n";
}

void showHelp(const char* name) {
    std::cout << "Usage: " << name << " [--vertices vertices.csv --edges edges.csv] "
              << "[--batch --out benchmark.csv --queries 50 --repeats 5 --seed 3530 "
              << "--heuristic-scale c]\n"
              << "Without --batch, a terminal menu runs. Load the two sample files to try it.\n";
}

}  // namespace

int main(int argc, char** argv) {
    try {
        std::string vertex_file, edge_file, output = "benchmark_results.csv";
        bool batch = false;
        std::size_t queries = 50, repeats = 5;
        std::uint32_t seed = 3530;
        double scale_override = 0;  // 0 means "use the provably safe scale computed at load"
        for (int i = 1; i < argc; ++i) {
            const std::string arg = argv[i];
            if (arg == "--help") { showHelp(argv[0]); return 0; }
            if (arg == "--batch") { batch = true; continue; }
            if (i + 1 >= argc) throw std::invalid_argument("Missing value for " + arg);
            const std::string value = argv[++i];
            if (arg == "--vertices") vertex_file = value;
            else if (arg == "--edges") edge_file = value;
            else if (arg == "--out") output = value;
            else if (arg == "--queries") queries = parsePositive(arg, value);
            else if (arg == "--repeats") repeats = parsePositive(arg, value);
            else if (arg == "--seed") seed = static_cast<std::uint32_t>(parsePositive(arg, value));
            else if (arg == "--heuristic-scale") {
                std::size_t used = 0;
                scale_override = std::stod(value, &used);
                if (used != value.size() || !(scale_override > 0 && scale_override <= 1))
                    throw std::invalid_argument("--heuristic-scale needs a number in (0, 1]");
            }
            else throw std::invalid_argument("Unknown option " + arg);
        }
        if (vertex_file.empty() != edge_file.empty())
            throw std::invalid_argument("Provide both --vertices and --edges");
        AdjacencyList graph;
        bool loaded = false;
        if (!vertex_file.empty()) {
            graph.loadCSV(vertex_file, edge_file);
            showStats(graph);
            loaded = true;
        }
        if (batch) {
            if (!loaded) throw std::invalid_argument("--batch requires --vertices and --edges");
            if (scale_override != 0) {
                graph.overrideHeuristicScale(scale_override);
                std::cout << "EXPERIMENT: A* heuristic scale overridden to " << scale_override
                          << "; every query is still cross-checked against Dijkstra.\n";
            }
            if (queries < 50)
                std::cerr << "Note: fewer than 50 queries is intended for development/testing only.\n";
            const auto selected = makeQueries(graph, queries, seed);
            const auto summary = benchmark(graph, selected, repeats, output);
            std::cout << "Benchmark complete: " << summary.queries << " queries ("
                      << summary.unreachable_queries << " unreachable), " << repeats
                      << " timed repetitions each; output: " << output << '\n'
                      << "Average expanded: Dijkstra " << summary.dijkstra_mean_expanded
                      << ", A* " << summary.astar_mean_expanded << '\n'
                      << "Mean of per-query median times (ms): Dijkstra "
                      << summary.dijkstra_mean_median_ms << ", A* "
                      << summary.astar_mean_median_ms << '\n';
            return 0;
        }
        intro();
        int source = -1, target = -1;
        std::vector<std::string> history;
        while (true) {
            menu();
            std::string choice;
            if (!std::getline(std::cin, choice)) break;
            try {
                if (choice == "9") break;
                if (choice == "1") {
                    std::string path1, path2;
                    std::cout << "Vertices CSV path: ";
                    if (!std::getline(std::cin, path1)) break;
                    std::cout << "Edges CSV path: ";
                    if (!std::getline(std::cin, path2)) break;
                    graph.loadCSV(path1, path2);
                    showStats(graph);
                    loaded = true; source = target = -1; history.clear();
                    continue;
                }
                if (!loaded && choice != "9") {
                    std::cout << "Load a graph first (option 1).\n";
                    continue;
                }
                if (choice == "2" || choice == "3") {
                    const auto id = readId(choice == "2" ? "Source ID: " : "Destination ID: ");
                    const int index = graph.find(id);
                    if (index < 0) throw std::invalid_argument("ID not found in graph");
                    if (choice == "2") source = index; else target = index;
                } else if (choice == "4" || choice == "5" || choice == "6") {
                    if (source < 0 || target < 0) { std::cout << "Select source and destination first.\n"; continue; }
                    double d_ms = 0, a_ms = 0;
                    const auto d = (choice != "5") ? timedSearch(graph, false, source, target, d_ms)
                                                   : SearchResult{};
                    const auto a = (choice != "4") ? timedSearch(graph, true, source, target, a_ms)
                                                   : SearchResult{};
                    if (choice != "5") printResult(graph, "Dijkstra", d, source, target, d_ms);
                    if (choice != "4") printResult(graph, "A*", a, source, target, a_ms);
                    if (choice == "6") std::cout << "Distance agreement: "
                        << (sameDistance(d, a) ? "PASS" : "FAIL") << '\n';
                    std::ostringstream line;
                    line << std::fixed << std::setprecision(1) << graph.vertex(source).external_id << " -> " << graph.vertex(target).external_id
                         << " | " << (choice == "4" ? "Dijkstra" : choice == "5" ? "A*" : "Both")
                         << " | " << (choice == "5" ? a.distance_m : d.distance_m) << " m";
                    history.push_back(line.str());
                    if (history.size() > 50) history.erase(history.begin());
                } else if (choice == "7") {
                    std::cout << "How many random queries? [50]: ";
                    std::string count_text;
                    if (!std::getline(std::cin, count_text)) break;
                    const std::size_t count = count_text.empty() ? 50 :
                        parsePositive("Query count", count_text);
                    std::cout << "Output CSV path [benchmark_results.csv]: ";
                    std::string file;
                    if (!std::getline(std::cin, file)) break;
                    if (file.empty()) file = "benchmark_results.csv";
                    const auto selected = makeQueries(graph, count, 3530);
                    const auto summary = benchmark(graph, selected, 5, file);
                    std::cout << summary.queries << " queries benchmarked; " << file << " saved.\n";
                } else if (choice == "8") {
                    for (const auto& item : history) std::cout << item << '\n';
                    if (history.empty()) std::cout << "No searches in history.\n";
                } else {
                    std::cout << "Invalid option.\n";
                }
            } catch (const std::exception& e) {
                std::cerr << "Error: " << e.what() << '\n';
            }
        }
    } catch (const std::exception& e) {
        std::cerr << "RouteBench error: " << e.what() << '\n';
        return 1;
    }
}
