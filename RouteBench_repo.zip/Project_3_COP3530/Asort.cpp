#include "Algorithms.h"
namespace routebench {
SearchResult astar(const AdjacencyList& graph, int source, int target) {
    return runBestFirst(graph, source, target, true);
}
}  // namespace routebench
