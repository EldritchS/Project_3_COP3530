# RouteBench Results — Florida DIMACS, experimental c=0.99

**Data provenance:** USA-road-d.FLA (9th DIMACS Challenge), 1,070,376 vertices, 2,712,798 arcs

Paired queries: **50**; unreachable: **0**; all distances agree and paths validate.

| Metric | Dijkstra | A* |
|---|---:|---:|
| Mean expanded vertices | 511773.80 | 174363.04 |
| Median expanded vertices | 490199.00 | 107817.00 |
| Mean of per-query median runtime (ms) | 104.646894 | 63.745624 |
| Median of per-query median runtime (ms) | 110.082565 | 34.257619 |

Use this table only with its stated dataset provenance.
