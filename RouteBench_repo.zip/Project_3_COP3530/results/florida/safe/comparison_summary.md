# RouteBench Results — Florida DIMACS, provable c

**Data provenance:** USA-road-d.FLA (9th DIMACS Challenge), 1,070,376 vertices, 2,712,798 arcs

Paired queries: **50**; unreachable: **0**; all distances agree and paths validate.

| Metric | Dijkstra | A* |
|---|---:|---:|
| Mean expanded vertices | 511773.80 | 323529.32 |
| Median expanded vertices | 490199.00 | 229350.50 |
| Mean of per-query median runtime (ms) | 112.522998 | 107.933537 |
| Median of per-query median runtime (ms) | 123.358711 | 78.276009 |

Use this table only with its stated dataset provenance.
