#pragma once
#include "AdjacencyList.h"
#include <cstddef>
#include <vector>

namespace routebench {

struct SearchResult {
    bool reachable = false;
    double distance_m = -1;
    std::size_t expanded = 0;
    std::vector<int> path;              // internal vertex indices, source through destination
    std::vector<double> edge_lengths;   // exact selected edge weights; handles parallel edges
    std::size_t hops() const { return edge_lengths.size(); }
};

SearchResult dijkstra(const AdjacencyList& graph, int source, int target);
SearchResult astar(const AdjacencyList& graph, int source, int target);
SearchResult runBestFirst(const AdjacencyList& graph, int source, int target,
                          bool use_geographic_heuristic);
bool validatePath(const AdjacencyList& graph, int source, int target,
                  const SearchResult& result);
bool sameDistance(const SearchResult& a, const SearchResult& b);

}  // namespace routebench
