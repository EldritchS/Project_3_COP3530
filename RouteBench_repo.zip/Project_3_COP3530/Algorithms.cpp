#include "Algorithms.h"

#include <algorithm>
#include <cmath>
#include <functional>
#include <limits>
#include <queue>
#include <stdexcept>

namespace routebench {
namespace {

struct QueueEntry {
    double f;
    double g;
    int vertex;
};
struct MinScore {
    bool operator()(const QueueEntry& a, const QueueEntry& b) const {
        if (a.f != b.f) return a.f > b.f;
        if (a.g != b.g) return a.g > b.g;
        return a.vertex > b.vertex;
    }
};

bool nearlyEqual(double a, double b) {
    return std::abs(a - b) <= 1e-6 + 1e-8 * std::max(std::abs(a), std::abs(b));
}

}  // namespace

SearchResult runBestFirst(const AdjacencyList& graph, int source, int target, bool use_heuristic) {
    const std::size_t n = graph.vertexCount();
    if (source < 0 || target < 0 || static_cast<std::size_t>(source) >= n ||
        static_cast<std::size_t>(target) >= n)
        throw std::out_of_range("Source or target vertex does not exist");

    const double infinity = std::numeric_limits<double>::infinity();
    std::vector<double> dist(n, infinity);
    std::vector<double> parent_edge(n, 0);
    std::vector<int> parent(n, -1);
    std::priority_queue<QueueEntry, std::vector<QueueEntry>, MinScore> queue;
    // Dijkstra is the special case h(v) = 0. A* uses a scaled great-circle lower bound.
    const double scale = use_heuristic ? graph.heuristicScale() : 0.0;
    dist[source] = 0;
    queue.push({scale * graph.straightLineDistance(source, target), 0, source});

    SearchResult result;
    while (!queue.empty()) {
        const QueueEntry cur = queue.top();
        queue.pop();
        if (cur.g != dist[cur.vertex]) continue; // stale lazy heap entry
        ++result.expanded;
        if (cur.vertex == target) {
            result.reachable = true;
            result.distance_m = cur.g;
            for (int v = target; v != -1; v = parent[v]) {
                result.path.push_back(v);
                if (parent[v] != -1) result.edge_lengths.push_back(parent_edge[v]);
            }
            std::reverse(result.path.begin(), result.path.end());
            std::reverse(result.edge_lengths.begin(), result.edge_lengths.end());
            return result;
        }
        for (const Edge& edge : graph.neighbors(cur.vertex)) {
            const double candidate = cur.g + edge.length_m;
            if (candidate < dist[edge.to]) {
                dist[edge.to] = candidate;
                parent[edge.to] = cur.vertex;
                parent_edge[edge.to] = edge.length_m;
                const double heuristic = use_heuristic ?
                    scale * graph.straightLineDistance(edge.to, target) : 0.0;
                queue.push({candidate + heuristic, candidate, edge.to});
            }
        }
    }
    return result;
}

bool sameDistance(const SearchResult& a, const SearchResult& b) {
    if (a.reachable != b.reachable) return false;
    return !a.reachable || nearlyEqual(a.distance_m, b.distance_m);
}

bool validatePath(const AdjacencyList& graph, int source, int target, const SearchResult& result) {
    if (!result.reachable)
        return result.path.empty() && result.edge_lengths.empty() && result.distance_m == -1;
    if (result.path.empty() || result.path.front() != source || result.path.back() != target ||
        result.edge_lengths.size() + 1 != result.path.size() ||
        !std::isfinite(result.distance_m) || result.distance_m < 0) return false;
    double total = 0;
    for (std::size_t i = 0; i < result.edge_lengths.size(); ++i) {
        const int u = result.path[i], v = result.path[i + 1];
        bool found = false;
        for (const Edge& edge : graph.neighbors(u)) {
            if (edge.to == v && nearlyEqual(edge.length_m, result.edge_lengths[i])) {
                found = true;
                break;
            }
        }
        if (!found) return false;
        total += result.edge_lengths[i];
    }
    return nearlyEqual(total, result.distance_m);
}

}  // namespace routebench
