#pragma once

#include <cstddef>
#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace routebench {

struct Vertex {
    std::int64_t external_id;  // ID used in the input files (64-bit, need not be contiguous)
    double latitude;
    double longitude;
};

struct Edge {
    int to;           // compact internal index of the destination vertex
    double length_m;  // road length in meters
};

struct ValidationStats {
    std::size_t vertices = 0;
    std::size_t edges = 0;
    std::size_t self_loops = 0;
    std::size_t parallel_directed_edges = 0;
    std::size_t edges_shorter_than_great_circle = 0;
    double heuristic_scale = 1.0;
    bool florida_bounds_ok = true;
    bool meets_size_target = false;
};

// Directed, weighted road network stored as an adjacency list.
// IDs in files are 64-bit; internally every vertex gets a compact int index 0..V-1.
class AdjacencyList {
public:
    void addVertex(std::int64_t id, double lat, double lon);
    void addEdge(std::int64_t source_id, std::int64_t dest_id, double length_m);
    void loadCSV(const std::string& vertices_path, const std::string& edges_path);

    int find(std::int64_t id) const;
    const Vertex& vertex(int internal_id) const;
    const std::vector<Edge>& neighbors(int internal_id) const;
    std::size_t vertexCount() const { return vertices_.size(); }
    std::size_t edgeCount() const { return edges_count_; }
    ValidationStats validate(bool require_florida_bounds = true) const;
    double straightLineDistance(int from, int to) const;

    // Largest c in [0, 1] with length(u,v) >= c * greatCircle(u,v) for every edge.
    // A* multiplies its Haversine estimate by c, which keeps the heuristic consistent
    // (and therefore admissible) even when the data source measured roads on a slightly
    // different Earth model or rounded lengths down.
    double heuristicScale() const { return heuristic_scale_; }
    // Experiment hook: replaces c with a value in (0, 1]. A value above the computed c is no
    // longer guaranteed admissible, so the benchmark's Dijkstra cross-check must stay on.
    void overrideHeuristicScale(double scale);

private:
    std::vector<Vertex> vertices_;
    std::vector<std::vector<Edge>> adjacency_;
    std::unordered_map<std::int64_t, int> index_;
    std::size_t edges_count_ = 0;
    std::size_t short_edges_ = 0;
    double heuristic_scale_ = 1.0;
    bool scale_overridden_ = false;
};

double haversineMeters(double lat1, double lon1, double lat2, double lon2);

}  // namespace routebench
