#include "Benchmark.h"

#include <algorithm>
#include <chrono>
#include <fstream>
#include <iomanip>
#include <numeric>
#include <random>
#include <stdexcept>
#include <utility>

namespace routebench {
namespace {

struct SccInfo {
    std::vector<int> id;
    std::vector<std::vector<int>> members;
    std::vector<int> sinks;
    int largest = -1;
};

SccInfo stronglyConnectedComponents(const AdjacencyList& graph) {
    const int n = static_cast<int>(graph.vertexCount());
    std::vector<std::vector<int>> reversed(n);
    for (int u = 0; u < n; ++u)
        for (const Edge& edge : graph.neighbors(u)) reversed[edge.to].push_back(u);

    std::vector<char> visited(n, false);
    std::vector<int> order;
    order.reserve(n);
    for (int root = 0; root < n; ++root) {
        if (visited[root]) continue;
        visited[root] = true;
        std::vector<std::pair<int, std::size_t>> stack{{root, 0}};
        while (!stack.empty()) {
            auto& frame = stack.back();
            const auto& neighbors = graph.neighbors(frame.first);
            if (frame.second < neighbors.size()) {
                int next = neighbors[frame.second++].to;
                if (!visited[next]) {
                    visited[next] = true;
                    stack.push_back({next, 0});
                }
            } else {
                order.push_back(frame.first);
                stack.pop_back();
            }
        }
    }
    SccInfo info;
    info.id.assign(n, -1);
    for (auto it = order.rbegin(); it != order.rend(); ++it) {
        const int root = *it;
        if (info.id[root] != -1) continue;
        const int component = static_cast<int>(info.members.size());
        info.members.emplace_back();
        std::vector<int> stack{root};
        info.id[root] = component;
        while (!stack.empty()) {
            const int u = stack.back();
            stack.pop_back();
            info.members.back().push_back(u);
            for (int v : reversed[u]) {
                if (info.id[v] == -1) {
                    info.id[v] = component;
                    stack.push_back(v);
                }
            }
        }
        if (info.largest == -1 ||
            info.members.back().size() > info.members[info.largest].size())
            info.largest = component;
    }
    std::vector<char> is_sink(info.members.size(), true);
    for (int u = 0; u < n; ++u)
        for (const Edge& edge : graph.neighbors(u))
            if (info.id[u] != info.id[edge.to]) is_sink[info.id[u]] = false;
    for (std::size_t i = 0; i < is_sink.size(); ++i)
        if (is_sink[i]) info.sinks.push_back(static_cast<int>(i));
    return info;
}

int drawVertex(const std::vector<int>& pool, std::mt19937& rng) {
    std::uniform_int_distribution<std::size_t> pick(0, pool.size() - 1);
    return pool[pick(rng)];
}

double median(std::vector<double>& values) {
    std::sort(values.begin(), values.end());
    const std::size_t middle = values.size() / 2;
    return values.size() % 2 ? values[middle] :
        (values[middle - 1] + values[middle]) / 2.0;
}

struct Measurement {
    SearchResult result;
    double median_ms = 0;
};

Measurement measure(const AdjacencyList& graph, const Query& query, bool use_astar,
                    std::size_t repeats) {
    const auto algo = use_astar ? astar : dijkstra;
    (void)algo(graph, query.source, query.target);  // warm-up, not timed
    std::vector<double> durations;
    durations.reserve(repeats);
    Measurement measured;
    for (std::size_t run = 0; run < repeats; ++run) {
        const auto start = std::chrono::steady_clock::now();
        SearchResult result = algo(graph, query.source, query.target);
        const auto end = std::chrono::steady_clock::now();
        if (!validatePath(graph, query.source, query.target, result))
            throw std::runtime_error("Search returned an invalid reconstructed path");
        if (run && !sameDistance(result, measured.result))
            throw std::runtime_error("Inconsistent search results between repetitions");
        durations.push_back(std::chrono::duration<double, std::milli>(end - start).count());
        measured.result = std::move(result);
    }
    measured.median_ms = median(durations);
    return measured;
}

}  // namespace

std::vector<Query> makeQueries(const AdjacencyList& graph, std::size_t count,
                               std::uint32_t seed) {
    if (graph.vertexCount() == 0) throw std::invalid_argument("Cannot benchmark empty graph");
    const auto scc = stronglyConnectedComponents(graph);
    std::mt19937 rng(seed);
    const auto& largest = scc.members[scc.largest];
    std::size_t unreachable_target = 0;
    if (scc.members.size() > 1 && count >= 10) unreachable_target = std::max<std::size_t>(1, count / 10);
    std::vector<Query> queries;
    queries.reserve(count);
    std::vector<int> with_outgoing;
    if (largest.size() == 1) {
        // An acyclic graph has no nontrivial SCC. Use random forward walks
        // so queries still test reachable, nonzero-length paths.
        for (std::size_t u = 0; u < graph.vertexCount(); ++u)
            if (!graph.neighbors(static_cast<int>(u)).empty())
                with_outgoing.push_back(static_cast<int>(u));
    }
    for (std::size_t i = 0; i < count - unreachable_target; ++i) {
        int u, v;
        if (largest.size() > 1) {
            u = drawVertex(largest, rng);
            v = drawVertex(largest, rng);
            while (v == u) v = drawVertex(largest, rng);
        } else if (!with_outgoing.empty()) {
            u = drawVertex(with_outgoing, rng);
            v = u;
            const int steps = 1 + static_cast<int>(rng() % 12);
            for (int step = 0; step < steps; ++step) {
                const auto& adjacent = graph.neighbors(v);
                if (adjacent.empty()) break;
                std::uniform_int_distribution<std::size_t> pick(0, adjacent.size() - 1);
                v = adjacent[pick(rng)].to;
            }
        } else {
            u = v = largest.front(); // Edgeless graph: only zero-hop reachable queries.
        }
        queries.push_back({u, v, false});
    }
    if (unreachable_target) {
        // A sink SCC cannot reach any other component. This guarantees genuinely
        // unreachable cases without expensive trial searches.
        const int sink = scc.sinks.front();
        std::vector<int> outside;
        for (std::size_t v = 0; v < graph.vertexCount(); ++v)
            if (scc.id[v] != sink) outside.push_back(static_cast<int>(v));
        for (std::size_t i = 0; i < unreachable_target; ++i) {
            queries.push_back({drawVertex(scc.members[sink], rng),
                               drawVertex(outside, rng), true});
        }
    }
    return queries;
}

BenchmarkSummary benchmark(const AdjacencyList& graph, const std::vector<Query>& queries,
                           std::size_t repeats, const std::string& csv_filename) {
    if (repeats == 0) throw std::invalid_argument("Benchmark repetitions must be positive");
    std::ofstream csv(csv_filename);
    if (!csv) throw std::runtime_error("Cannot write benchmark CSV: " + csv_filename);
    csv << "query_id,src_id,dst_id,algorithm,reachable,distance_m,hops,expanded,median_ms,path_valid\n";
    csv << std::fixed << std::setprecision(8);
    BenchmarkSummary summary;
    summary.queries = queries.size();
    for (std::size_t i = 0; i < queries.size(); ++i) {
        const Query& query = queries[i];
        const auto d = measure(graph, query, false, repeats);
        const auto a = measure(graph, query, true, repeats);
        if (!sameDistance(d.result, a.result))
            throw std::runtime_error("A* and Dijkstra disagree on query " + std::to_string(i));
        if (query.expected_unreachable && d.result.reachable)
            throw std::runtime_error("Query expected to be unreachable is reachable");
        if (!d.result.reachable) ++summary.unreachable_queries;
        const auto emit = [&](const char* algorithm, const Measurement& m) {
            csv << i << ',' << graph.vertex(query.source).external_id << ','
                << graph.vertex(query.target).external_id << ',' << algorithm << ','
                << (m.result.reachable ? 1 : 0) << ',' << m.result.distance_m << ','
                << m.result.hops() << ',' << m.result.expanded << ',' << m.median_ms
                << ",1\n";
        };
        emit("dijkstra", d);
        emit("astar", a);
        summary.dijkstra_mean_expanded += static_cast<double>(d.result.expanded);
        summary.astar_mean_expanded += static_cast<double>(a.result.expanded);
        summary.dijkstra_mean_median_ms += d.median_ms;
        summary.astar_mean_median_ms += a.median_ms;
    }
    if (!csv) throw std::runtime_error("Error writing CSV: " + csv_filename);
    if (summary.queries) {
        const double n = static_cast<double>(summary.queries);
        summary.dijkstra_mean_expanded /= n;
        summary.astar_mean_expanded /= n;
        summary.dijkstra_mean_median_ms /= n;
        summary.astar_mean_median_ms /= n;
    }
    return summary;
}

}  // namespace routebench
