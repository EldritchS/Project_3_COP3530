#!/usr/bin/env python3
"""Download the DIMACS Florida road network and convert it to RouteBench CSV files.

Tries the official 9th DIMACS Challenge server first, then a public GitHub LFS
mirror (petgraph's benchmark data). Every file is checked against a SHA-256
digest of the uncompressed text, so both sources must produce identical data.
Uses only the Python standard library.
"""
import argparse
import gzip
import hashlib
import pathlib
import shutil
import sys
import urllib.request

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))
from dimacs_to_csv import convert  # noqa: E402

FILES = {
    'USA-road-d.FLA.co': 'e9ef8ff417f2e0b19faf51918b87f7e77d99269fa95726d105fdf47cd893e90d',
    'USA-road-d.FLA.gr': '47a3e851dea2bf27d6c939542e569fa9b5e6f2c8f11e8af3187d87c28435a85d',
}
OFFICIAL = 'http://www.diag.uniroma1.it/challenge9/data/USA-road-d/{name}.gz'
MIRROR = ('https://media.githubusercontent.com/media/petgraph/petgraph/'
          'ed47e71dcdcdde865affb7bac4e4c58194a96139/'
          'crates/algorithms/benches/cases/shortest_path/{name}')


def sha256(path):
    digest = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            digest.update(block)
    return digest.hexdigest()


def download(name, raw_dir):
    target = raw_dir / name
    if target.exists() and sha256(target) == FILES[name]:
        print(f'{name}: already present and verified')
        return target
    for url, compressed in ((OFFICIAL.format(name=name), True), (MIRROR.format(name=name), False)):
        partial = raw_dir / (name + '.partial')
        try:
            print(f'{name}: downloading {url}')
            with urllib.request.urlopen(url, timeout=120) as response, partial.open('wb') as out:
                shutil.copyfileobj(response, out)
            if compressed:
                with gzip.open(partial, 'rb') as src, target.open('wb') as out:
                    shutil.copyfileobj(src, out)
                partial.unlink()
            else:
                partial.replace(target)
            if sha256(target) == FILES[name]:
                print(f'{name}: SHA-256 verified')
                return target
            print(f'{name}: checksum mismatch from {url}; trying next source')
        except Exception as error:  # network errors, HTTP errors, bad gzip
            print(f'{name}: failed from {url} ({error}); trying next source')
        for leftover in (partial, target):
            if leftover.exists():
                leftover.unlink()
    raise SystemExit(f'Could not obtain a verified copy of {name}')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw-dir', default='data/raw')
    parser.add_argument('--output-dir', default='data/florida')
    args = parser.parse_args()
    raw_dir = pathlib.Path(args.raw_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)
    co = download('USA-road-d.FLA.co', raw_dir)
    gr = download('USA-road-d.FLA.gr', raw_dir)
    vertices, arcs = convert(co, gr, args.output_dir)
    print(f'Ready: {vertices} vertices, {arcs} directed edges in {args.output_dir}')


if __name__ == '__main__':
    main()
