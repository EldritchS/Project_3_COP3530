#!/usr/bin/env python3
"""Audit paired RouteBench benchmark CSV and generate reproducible result artifacts.

Refuses incomplete pairs, inconsistent reachability or distances, invalid paths,
and incomplete or duplicate query records. No performance numbers are invented.
"""
import argparse
import csv
import datetime
import json
import math
import pathlib
import statistics


def finite_nonnegative(value, name):
    x = float(value)
    if not math.isfinite(x) or x < 0:
        raise ValueError(f"{name}: expected a finite nonnegative number, got {value!r}")
    return x


def analyze(path):
    path = pathlib.Path(path)
    with path.open(newline='', encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    required = {'query_id', 'src_id', 'dst_id', 'algorithm', 'reachable',
                'distance_m', 'hops', 'expanded', 'median_ms', 'path_valid'}
    if not rows or not required.issubset(rows[0]):
        raise ValueError('Benchmark CSV is empty or missing expected columns')
    queries = {}
    for row in rows:
        query_id = int(row['query_id'])
        algorithm = row['algorithm']
        if algorithm not in {'dijkstra', 'astar'}:
            raise ValueError(f'Unexpected algorithm {algorithm!r}')
        if row['reachable'] not in {'0', '1'} or row['path_valid'] != '1':
            raise ValueError(f'Invalid search/path validation for query {query_id}')
        finite_nonnegative(row['median_ms'], 'median_ms')
        finite_nonnegative(row['expanded'], 'expanded')
        if int(row['hops']) < 0:
            raise ValueError('Negative hop count')
        if row['reachable'] == '1':
            finite_nonnegative(row['distance_m'], 'reachable distance')
        elif float(row['distance_m']) != -1:
            raise ValueError('Unreachable distance must equal -1')
        record = queries.setdefault(query_id, {})
        if algorithm in record:
            raise ValueError(f'Duplicate {algorithm} for query {query_id}')
        record[algorithm] = row
    if set(queries) != set(range(len(queries))):
        raise ValueError('Query IDs must be contiguous from 0')
    for qid, pair in queries.items():
        if set(pair) != {'dijkstra', 'astar'}:
            raise ValueError(f'Incomplete algorithm pair for query {qid}')
        a, b = pair['dijkstra'], pair['astar']
        for field in ('src_id', 'dst_id', 'reachable'):
            if a[field] != b[field]:
                raise ValueError(f'Inconsistent {field} on query {qid}')
        if a['reachable'] == '1':
            da, db = float(a['distance_m']), float(b['distance_m'])
            if abs(da - db) > 1e-6 + 1e-8 * max(abs(da), abs(db)):
                raise ValueError(f'Distance disagreement on query {qid}: {da}, {db}')
    values = {}
    for algorithm in ('dijkstra', 'astar'):
        subset = [pair[algorithm] for pair in queries.values()]
        ex = [int(x['expanded']) for x in subset]
        tm = [float(x['median_ms']) for x in subset]
        values[algorithm] = {
            'mean_expanded': statistics.mean(ex),
            'median_expanded': statistics.median(ex),
            'mean_of_query_median_ms': statistics.mean(tm),
            'median_of_query_median_ms': statistics.median(tm),
            'min_query_median_ms': min(tm),
            'max_query_median_ms': max(tm),
            'expanded_min': min(ex),
            'expanded_max': max(ex),
        }
    total = len(queries)
    unreachable = sum(pair['dijkstra']['reachable'] == '0' for pair in queries.values())
    result = {
        'schema': 'routebench-comparison-v1',
        'source_csv': path.name,
        'total_queries': total,
        'unreachable_queries': unreachable,
        'reachable_queries': total - unreachable,
        'all_path_valid': True,
        'all_distances_agree': True,
        'algorithms': values,
    }
    d, a = values['dijkstra'], values['astar']
    result['astar_mean_expansion_reduction_percent'] = (100 *
        (d['mean_expanded'] - a['mean_expanded']) / d['mean_expanded']
        if d['mean_expanded'] else None)
    result['astar_mean_runtime_change_percent'] = (100 *
        (a['mean_of_query_median_ms'] - d['mean_of_query_median_ms']) /
        d['mean_of_query_median_ms']
        if d['mean_of_query_median_ms'] else None)
    return result


def write_summary(summary, output_dir, label, provenance):
    output_dir = pathlib.Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    payload = {**summary, 'dataset_label': label, 'provenance': provenance,
               'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (output_dir / 'comparison_summary.json').write_text(json.dumps(payload, indent=2) + '\n')
    d = payload['algorithms']['dijkstra']
    a = payload['algorithms']['astar']
    notes = [
        f'# RouteBench Results — {label}', '',
        f'**Data provenance:** {provenance}', '',
        f"Paired queries: **{payload['total_queries']}**; unreachable: **{payload['unreachable_queries']}**; all distances agree and paths validate.", '',
        '| Metric | Dijkstra | A* |', '|---|---:|---:|',
        f"| Mean expanded vertices | {d['mean_expanded']:.2f} | {a['mean_expanded']:.2f} |",
        f"| Median expanded vertices | {d['median_expanded']:.2f} | {a['median_expanded']:.2f} |",
        f"| Mean of per-query median runtime (ms) | {d['mean_of_query_median_ms']:.6f} | {a['mean_of_query_median_ms']:.6f} |",
        f"| Median of per-query median runtime (ms) | {d['median_of_query_median_ms']:.6f} | {a['median_of_query_median_ms']:.6f} |",
        '', 'Use this table only with its stated dataset provenance.',
        ''
    ]
    (output_dir / 'comparison_summary.md').write_text('\n'.join(notes))
    # Matplotlib is optional: tables and JSON still work with Python stdlib alone.
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        for field, axis_label, out_file in (
            ('mean_expanded', 'Mean expanded vertices', 'expanded_vertices.png'),
            ('mean_of_query_median_ms', 'Mean query-median runtime (ms)', 'query_runtime.png'),
        ):
            fig, ax = plt.subplots(figsize=(6.7, 3.7))
            ax.bar(['Dijkstra', 'A*'], [d[field], a[field]])
            ax.set_ylabel(axis_label)
            ax.set_title(label)
            ax.set_ylim(bottom=0)
            fig.tight_layout()
            fig.savefig(output_dir / out_file, dpi=170)
            plt.close(fig)
    except ImportError:
        pass


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('csv', type=pathlib.Path)
    p.add_argument('--output-dir', type=pathlib.Path, required=True)
    p.add_argument('--label', required=True)
    p.add_argument('--provenance', required=True)
    args = p.parse_args()
    summary = analyze(args.csv)
    write_summary(summary, args.output_dir, args.label, args.provenance)
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
