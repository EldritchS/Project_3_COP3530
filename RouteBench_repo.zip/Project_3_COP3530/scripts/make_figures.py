#!/usr/bin/env python3
"""Draw the report figure from the two Florida benchmark CSVs (no numbers are typed in)."""
import argparse, csv, pathlib, statistics
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

BLUE, ORANGE, AQUA = '#257de0', '#f47230', '#00b894'
INK, MUTED, GRID = '#1f1f1f', '#6b6b6b', '#e6e6e6'


def load(path):
    queries = {}
    with open(path, newline='') as f:
        for row in csv.DictReader(f):
            queries.setdefault(int(row['query_id']), {})[row['algorithm']] = row
    return [queries[i] for i in sorted(queries)]


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('safe_csv'); p.add_argument('fast_csv'); p.add_argument('out')
    p.add_argument('--fast-label', default='A* (c = 0.99)')
    args = p.parse_args()
    safe, fast = load(args.safe_csv), load(args.fast_csv)
    km = [float(q['dijkstra']['distance_m']) / 1000 for q in safe]
    series = [
        ('Dijkstra', BLUE, 'o', [int(q['dijkstra']['expanded']) for q in safe],
         statistics.mean(float(q['dijkstra']['median_ms']) for q in safe)),
        ('A* (provable c)', ORANGE, 's', [int(q['astar']['expanded']) for q in safe],
         statistics.mean(float(q['astar']['median_ms']) for q in safe)),
        (args.fast_label, AQUA, '^', [int(q['astar']['expanded']) for q in fast],
         statistics.mean(float(q['astar']['median_ms']) for q in fast)),
    ]
    plt.rcParams.update({'font.size': 9, 'axes.edgecolor': MUTED, 'axes.labelcolor': INK,
                         'xtick.color': MUTED, 'ytick.color': MUTED})
    fig, (left, right) = plt.subplots(1, 2, figsize=(7.2, 2.9), gridspec_kw={'width_ratios': [1.6, 1]})
    for name, color, marker, expanded, _ in series:
        left.scatter(km, [e / 1000 for e in expanded], s=22, marker=marker, color=color,
                     edgecolors='white', linewidths=0.8, label=name, zorder=3)
    left.set_xlabel('Shortest route length (km)')
    left.set_ylabel('Vertices expanded (thousands)')
    left.set_title('Search effort per query (50 queries)', color=INK, fontsize=9.5, loc='left')
    left.legend(frameon=False, fontsize=8, loc='upper left')
    right.bar([s[0].replace(' (', '\n(') for s in series], [s[4] for s in series],
              color=[s[1] for s in series], width=0.6, edgecolor='white', linewidth=2, zorder=3)
    for i, s in enumerate(series):
        right.text(i, s[4] + 2, f'{s[4]:.1f}', ha='center', va='bottom', color=INK, fontsize=8.5)
    right.set_ylabel('Time (ms)')
    right.set_title('Mean query time', color=INK, fontsize=9.5, loc='left')
    right.set_ylim(0, max(s[4] for s in series) * 1.18)
    right.tick_params(axis='x', labelsize=7.5)
    for ax in (left, right):
        ax.grid(axis='y', color=GRID, zorder=0)
        ax.spines[['top', 'right']].set_visible(False)
        ax.set_ylim(bottom=0)
    fig.tight_layout()
    fig.savefig(args.out, dpi=220)


if __name__ == '__main__':
    main()
