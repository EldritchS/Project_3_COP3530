#!/usr/bin/env python3
"""Convert a 9th DIMACS Challenge road graph (.gr + .co) into RouteBench CSV files.

Input  (plain text or .gz):
  USA-road-d.FLA.co  lines "v <id> <longitude*1e6> <latitude*1e6>"
  USA-road-d.FLA.gr  lines "a <src> <dst> <length>" with length in units of 0.1 m
Output:
  vertices.csv  vertex_id,latitude,longitude
  edges.csv     src_id,dst_id,length_m

Numbers are converted with integer arithmetic, so no rounding is introduced.
The script refuses files whose counts do not match their "p" header lines.
"""
import argparse
import gzip
import pathlib


def open_text(path):
    path = pathlib.Path(path)
    if path.suffix == '.gz':
        return gzip.open(path, 'rt', encoding='ascii')
    return path.open('r', encoding='ascii')


def micro_degrees(value):
    """Format an integer number of millionths of a degree as an exact decimal string."""
    sign = '-' if value < 0 else ''
    value = abs(value)
    return f'{sign}{value // 1_000_000}.{value % 1_000_000:06d}'


def decimeters(value):
    """Format an integer number of 0.1 m units as meters with one decimal place."""
    if value < 0:
        raise ValueError(f'negative arc length {value}')
    return f'{value // 10}.{value % 10}'


def convert(co_path, gr_path, out_dir):
    out_dir = pathlib.Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    declared_vertices = None
    seen = None
    with open_text(co_path) as src, (out_dir / 'vertices.csv').open('w', newline='') as out:
        out.write('vertex_id,latitude,longitude\n')
        for number, line in enumerate(src, 1):
            parts = line.split()
            if not parts or parts[0] == 'c':
                continue
            if parts[0] == 'p':
                declared_vertices = int(parts[-1])
                seen = bytearray(declared_vertices + 1)
                continue
            if parts[0] != 'v' or len(parts) != 4 or seen is None:
                raise ValueError(f'{co_path}:{number}: unexpected line {line.strip()!r}')
            vid, lon, lat = int(parts[1]), int(parts[2]), int(parts[3])
            if not 1 <= vid <= declared_vertices or seen[vid]:
                raise ValueError(f'{co_path}:{number}: invalid or duplicate vertex {vid}')
            seen[vid] = 1
            out.write(f'{vid},{micro_degrees(lat)},{micro_degrees(lon)}\n')
    if seen is None or sum(seen) != declared_vertices:
        raise ValueError('coordinate file does not list every declared vertex exactly once')

    declared_arcs = None
    arcs = 0
    with open_text(gr_path) as src, (out_dir / 'edges.csv').open('w', newline='') as out:
        out.write('src_id,dst_id,length_m\n')
        for number, line in enumerate(src, 1):
            parts = line.split()
            if not parts or parts[0] == 'c':
                continue
            if parts[0] == 'p':
                if int(parts[2]) != declared_vertices:
                    raise ValueError('graph and coordinate files disagree on vertex count')
                declared_arcs = int(parts[3])
                continue
            if parts[0] != 'a' or len(parts) != 4 or declared_arcs is None:
                raise ValueError(f'{gr_path}:{number}: unexpected line {line.strip()!r}')
            u, v, w = int(parts[1]), int(parts[2]), int(parts[3])
            if not (1 <= u <= declared_vertices and 1 <= v <= declared_vertices):
                raise ValueError(f'{gr_path}:{number}: arc endpoint out of range')
            out.write(f'{u},{v},{decimeters(w)}\n')
            arcs += 1
    if arcs != declared_arcs:
        raise ValueError(f'expected {declared_arcs} arcs, found {arcs}')
    return declared_vertices, arcs


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('co', help='DIMACS coordinate file (.co or .co.gz)')
    parser.add_argument('gr', help='DIMACS distance graph file (.gr or .gr.gz)')
    parser.add_argument('--output-dir', default='data/florida')
    args = parser.parse_args()
    vertices, arcs = convert(args.co, args.gr, args.output_dir)
    print(f'Wrote {vertices} vertices and {arcs} directed edges to {args.output_dir}')


if __name__ == '__main__':
    main()
