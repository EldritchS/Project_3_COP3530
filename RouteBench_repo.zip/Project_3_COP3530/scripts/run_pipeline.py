#!/usr/bin/env python3
"""Run the full RouteBench Florida pipeline with one command.

Steps: download + verify + convert the DIMACS Florida data, build the C++ program,
run all tests, run both 50-query benchmarks (provable heuristic and c = 0.99),
audit both CSVs, and draw the comparison figure. Stops at the first failure.

    python3 scripts/run_pipeline.py            # from the repository root
"""
import argparse
import pathlib
import platform
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
PROVENANCE = 'USA-road-d.FLA (9th DIMACS Challenge), 1,070,376 vertices, 2,712,798 arcs'


def run(command, **kwargs):
    print('\n$ ' + ' '.join(str(part) for part in command), flush=True)
    subprocess.run([str(part) for part in command], cwd=ROOT, check=True, **kwargs)


def main():
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('--queries', default='50')
    parser.add_argument('--repeats', default='5')
    parser.add_argument('--seed', default='3530')
    parser.add_argument('--fast-scale', default='0.99')
    parser.add_argument('--results', default='results/florida')
    args = parser.parse_args()
    python = sys.executable
    results = pathlib.Path(args.results)
    (ROOT / results).mkdir(parents=True, exist_ok=True)

    run([python, 'scripts/fetch_florida.py'])
    run(['cmake', '-S', '.', '-B', 'build', '-DCMAKE_BUILD_TYPE=Release'])
    run(['cmake', '--build', 'build', '--config', 'Release', '-j'])
    exe_dir = ROOT / 'build' / ('Release' if platform.system() == 'Windows' else '')
    suffix = '.exe' if platform.system() == 'Windows' else ''
    routebench = exe_dir / ('routebench' + suffix)
    run([exe_dir / ('routebench_tests' + suffix), '--stress'])
    run([python, '-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py'])

    graph = ['--vertices', 'data/florida/vertices.csv', '--edges', 'data/florida/edges.csv',
             '--batch', '--queries', args.queries, '--repeats', args.repeats, '--seed', args.seed]
    runs = [('safe', 'provable c', []),
            ('c099', 'experimental c=' + args.fast_scale, ['--heuristic-scale', args.fast_scale])]
    for name, label, extra in runs:
        csv_path = results / f'benchmark_{name}.csv'
        with open(ROOT / results / f'run_{name}.log', 'w') as log:
            run([routebench, *graph, *extra, '--out', csv_path], stdout=log)
        print((ROOT / results / f'run_{name}.log').read_text())
        run([python, 'scripts/analyze_benchmark.py', csv_path, '--output-dir', results / name,
             '--label', f'Florida DIMACS, {label}', '--provenance', PROVENANCE],
            stdout=subprocess.DEVNULL)
    run([python, 'scripts/make_figures.py', results / 'benchmark_safe.csv',
         results / 'benchmark_c099.csv', results / 'figure_comparison.svg',
         '--fast-label', f'A* (c = {args.fast_scale})'])
    print(f'\nPipeline complete. Results are in {results}/')


if __name__ == '__main__':
    main()
