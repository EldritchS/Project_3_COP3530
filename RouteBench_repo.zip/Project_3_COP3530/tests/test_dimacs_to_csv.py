"""Checks for the DIMACS-to-CSV converter (exact number formatting and input validation)."""
import importlib.util
import pathlib
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('dimacs_to_csv', ROOT / 'scripts' / 'dimacs_to_csv.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

CO = 'c sample\np aux sp co 3\nv 1 -87398204 30620944\nv 2 -82000005 27000000\nv 3 -80500000 25999999\n'
GR = 'c sample\np sp 3 3\na 1 2 14188\na 2 1 14188\na 2 3 7\n'


class ConverterTests(unittest.TestCase):
    def setUp(self):
        self.dir = pathlib.Path(tempfile.mkdtemp())

    def run_convert(self, co=CO, gr=GR):
        (self.dir / 'g.co').write_text(co)
        (self.dir / 'g.gr').write_text(gr)
        return mod.convert(self.dir / 'g.co', self.dir / 'g.gr', self.dir / 'out')

    def test_exact_conversion(self):
        self.assertEqual(self.run_convert(), (3, 3))
        vertices = (self.dir / 'out' / 'vertices.csv').read_text().splitlines()
        edges = (self.dir / 'out' / 'edges.csv').read_text().splitlines()
        self.assertEqual(vertices[0], 'vertex_id,latitude,longitude')
        self.assertEqual(vertices[1], '1,30.620944,-87.398204')
        self.assertEqual(vertices[2], '2,27.000000,-82.000005')
        self.assertEqual(edges[1:], ['1,2,1418.8', '2,1,1418.8', '2,3,0.7'])

    def test_missing_vertex_rejected(self):
        with self.assertRaises(ValueError):
            self.run_convert(co=CO.replace('v 3 -80500000 25999999\n', ''))

    def test_arc_count_mismatch_rejected(self):
        with self.assertRaises(ValueError):
            self.run_convert(gr=GR.replace('p sp 3 3', 'p sp 3 4'))

    def test_endpoint_out_of_range_rejected(self):
        with self.assertRaises(ValueError):
            self.run_convert(gr=GR.replace('a 2 3 7', 'a 2 9 7'))


if __name__ == '__main__':
    unittest.main()
