#include "AdjacencyList.h"
#include "Algorithms.h"
#include "Benchmark.h"

#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <limits>
#include <random>
#include <stdexcept>
#include <string>
#include <vector>

using namespace routebench;
namespace {
int tests = 0;

void check(bool condition, const char* message) {
    ++tests;
    if (!condition) throw std::runtime_error(message);
}

bool close(double x, double y) {
    return std::abs(x - y) <= 1e-6 + 1e-8 * std::max(std::abs(x), std::abs(y));
}

bool throwsOnLoad(const std::string& vertices, const std::string& edges) {
    std::ofstream v("test_vertices_bad.csv"); v << vertices; v.close();
    std::ofstream e("test_edges_bad.csv"); e << edges; e.close();
    try {
        AdjacencyList graph;
        graph.loadCSV("test_vertices_bad.csv", "test_edges_bad.csv");
    } catch (const std::exception&) { return true; }
    return false;
}

void testLoaderAndValidation() {
    AdjacencyList graph;
    graph.addVertex(5000000001LL, 27.950, -82.460);
    graph.addVertex(5000000002LL, 27.950, -82.460);
    graph.addVertex(5000000003LL, 27.951, -82.461);
    graph.addEdge(5000000001LL, 5000000002LL, 5.5);
    graph.addEdge(5000000001LL, 5000000002LL, 6.0);
    graph.addEdge(5000000002LL, 5000000002LL, 0.0);
    graph.addEdge(5000000002LL, 5000000003LL, 300.0);
    auto stats = graph.validate();
    check(stats.vertices == 3 && stats.edges == 4, "Vertex or edge count incorrect");
    check(stats.parallel_directed_edges == 1, "Duplicate edge detection wrong");
    check(stats.self_loops == 1, "Self-loop detection wrong");
    check(graph.find(5000000001LL) == 0, "64-bit ID compression incorrect");
    check(graph.find(5) == -1, "Unknown vertex lookup incorrect");
    const auto d = dijkstra(graph, 0, 2);
    const auto a = astar(graph, 0, 2);
    check(d.reachable && close(d.distance_m, 305.5), "Shortest path with parallel edges incorrect");
    check(sameDistance(d, a), "A* does not match Dijkstra on parallel edges");
    check(validatePath(graph, 0, 2, d), "Parallel-edge path reconstruction invalid");
    check(d.path.size() == 3, "Wrong path size");
}

void testCSVAndRollback() {
    {
        std::ofstream v("test_vertices.csv");
        v << "vertex_id,latitude,longitude\n5000000001,27.95,-82.46\n5000000002,27.95,-82.46\n";
        std::ofstream e("test_edges.csv");
        e << "src_id,dst_id,length_m\n5000000001,5000000002,1.25\n";
    }
    AdjacencyList g;
    g.loadCSV("test_vertices.csv", "test_edges.csv");
    check(g.vertexCount() == 2 && g.edgeCount() == 1, "CSV loading failed");
    const bool invalid = throwsOnLoad(
        "vertex_id,latitude,longitude\n1,27.95,-82.46\n1,27.95,-82.46\n",
        "src_id,dst_id,length_m\n1,1,1\n");
    check(invalid, "Duplicate vertex IDs must be rejected");
    try { g.loadCSV("test_vertices_bad.csv", "test_edges_bad.csv"); }
    catch (const std::exception&) {}
    check(g.vertexCount() == 2 && g.edgeCount() == 1, "CSV load failure changed existing graph");
    check(throwsOnLoad("1,27.95,-82.46\n", "1,2,1\n"), "Missing endpoints not rejected");
    check(throwsOnLoad("1,27.95,-82.46\n2,27.95,-82.46\n", "1,2,-2\n"),
          "Negative edge weights not rejected");
    check(throwsOnLoad("1,27.95,-82.46\n2,27.95,-82.46\n", "1,2,nan\n"),
          "NaN weights not rejected");
    check(throwsOnLoad("1,27.95,-82.46\n2,27.95,-82.46\n", "1,2\n"),
          "Edge rows with missing fields not rejected");
    check(throwsOnLoad("1,27.95,-82.46\n2,95.0,-82.46\n", "1,2,1\n"),
          "Out-of-range latitude not rejected");
    std::remove("test_vertices.csv"); std::remove("test_edges.csv");
    std::remove("test_vertices_bad.csv"); std::remove("test_edges_bad.csv");
}

void testHeuristicScale() {
    // Two vertices about 111.2 km apart on a meridian.
    AdjacencyList g;
    g.addVertex(1, 27.0, -82.0);
    g.addVertex(2, 28.0, -82.0);
    const double chord = g.straightLineDistance(0, 1);
    g.addEdge(1, 2, chord * 1.5);
    check(close(g.heuristicScale(), 1.0), "Scale must stay 1 when no edge is shorter than its chord");
    g.addEdge(2, 1, chord * 0.8);  // data measured on a smaller Earth model, for example
    check(std::abs(g.heuristicScale() - 0.8) < 1e-12, "Scale must equal the smallest length/chord ratio");
    const auto stats = g.validate();
    check(stats.edges_shorter_than_great_circle == 1, "Short-edge count wrong");
    check(std::abs(stats.heuristic_scale - 0.8) < 1e-12, "Validation must report the scale");
    const auto d = dijkstra(g, 1, 0), a = astar(g, 1, 0);
    check(close(d.distance_m, chord * 0.8) && sameDistance(d, a), "Scaled A* wrong on short edge");
    g.overrideHeuristicScale(1.0);
    check(close(g.heuristicScale(), 1.0), "Override not applied");
    check(std::abs(g.validate().heuristic_scale - 0.8) < 1e-12,
          "Validation must still report the provably safe scale after an override");
    bool rejected = false;
    try { g.overrideHeuristicScale(1.5); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, "Scale above 1 must be rejected");
    g.overrideHeuristicScale(0.8);
    // Without scaling, h(source) = chord > true distance 0.8 * chord, which would be inadmissible.
    check(astar(g, 1, 0).expanded <= dijkstra(g, 1, 0).expanded, "A* expanded more than Dijkstra");
}

void testUnreachableAndSelf() {
    AdjacencyList g;
    for (int i = 0; i < 4; ++i) g.addVertex(i, 27.95, -82.46);
    g.addEdge(0, 1, 1.0);
    g.addEdge(1, 0, 1.0);
    g.addEdge(2, 3, 1.0);
    auto d = dijkstra(g, 0, 3);
    auto a = astar(g, 0, 3);
    check(!d.reachable && !a.reachable, "Unreachable query considered reachable");
    check(validatePath(g, 0, 3, d) && sameDistance(d, a), "Unreachable-path behavior wrong");
    auto self = astar(g, 2, 2);
    check(self.reachable && self.distance_m == 0 && self.hops() == 0 &&
          self.path.size() == 1, "Same-source-destination query wrong");
}

// shorter_edges = true draws weights from 0.5x to 1.3x the great-circle distance, so many edges
// violate "length >= chord". A* must still agree with the Floyd-Warshall oracle via the scale.
void testRandomizedIndependentOracle(bool shorter_edges) {
    std::mt19937 rng(shorter_edges ? 2026 : 1804);
    std::uniform_real_distribution<double> lat(27.8, 28.0), lon(-82.6, -82.3);
    std::uniform_int_distribution<int> extra(0, 2000);
    std::uniform_real_distribution<double> factor(0.5, 1.3);
    for (int trial = 0; trial < 60; ++trial) {
        const int n = 12;
        AdjacencyList g;
        for (int i = 0; i < n; ++i) g.addVertex(8000000000LL + i, lat(rng), lon(rng));
        const double inf = std::numeric_limits<double>::infinity();
        std::vector<std::vector<double>> expected(n, std::vector<double>(n, inf));
        for (int i = 0; i < n; ++i) expected[i][i] = 0;
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                if (rng() % 4 == 0) {
                    const double chord = g.straightLineDistance(i, j);
                    const double weight = shorter_edges ? chord * factor(rng) : chord + extra(rng);
                    g.addEdge(8000000000LL + i, 8000000000LL + j, weight);
                    expected[i][j] = std::min(expected[i][j], weight);
                }
            }
        }
        // Floyd-Warshall is an independent shortest-path oracle.
        for (int k = 0; k < n; ++k)
            for (int i = 0; i < n; ++i)
                for (int j = 0; j < n; ++j)
                    if (std::isfinite(expected[i][k]) && std::isfinite(expected[k][j]))
                        expected[i][j] = std::min(expected[i][j], expected[i][k] + expected[k][j]);
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                const auto d = dijkstra(g, i, j), a = astar(g, i, j);
                const bool reachable = std::isfinite(expected[i][j]);
                check(d.reachable == reachable && a.reachable == reachable, "Reachability mismatches oracle");
                check(!reachable || (close(d.distance_m, expected[i][j]) &&
                      close(a.distance_m, expected[i][j])), "Shortest distance mismatches oracle");
                check(sameDistance(d, a), "Dijkstra and A* distances differ");
                check(validatePath(g, i, j, d) && validatePath(g, i, j, a),
                      "At least one reconstructed path invalid");
            }
        }
    }
}

void testBenchmarkAndSCC() {
    AdjacencyList g;
    for (int i = 0; i < 8; ++i) g.addVertex(8000000000LL + i, 27.95, -82.46);
    for (int i = 0; i < 5; ++i) {
        g.addEdge(8000000000LL + i, 8000000000LL + (i + 1) % 5, 1.0);
    }
    // Sink SCC has no outgoing edges; unreachable queries are guaranteed.
    g.addEdge(8000000005LL, 8000000006LL, 1);
    g.addEdge(8000000006LL, 8000000007LL, 1);
    g.addEdge(8000000007LL, 8000000005LL, 1);
    auto queries = makeQueries(g, 20, 3530);
    auto repeat = makeQueries(g, 20, 3530);
    check(queries.size() == 20, "Wrong number of generated queries");
    for (std::size_t i = 0; i < queries.size(); ++i) {
        check(queries[i].source == repeat[i].source &&
              queries[i].target == repeat[i].target, "Benchmark query generation not reproducible");
    }
    auto summary = benchmark(g, queries, 3, "test_benchmark.csv");
    check(summary.queries == 20 && summary.unreachable_queries == 2,
          "Benchmark unreachable query generation wrong");
    std::ifstream csv("test_benchmark.csv");
    std::string line;
    int lines = 0;
    while (std::getline(csv, line)) ++lines;
    check(lines == 41, "Incorrect CSV row count (header plus 2 rows per query)");
    std::remove("test_benchmark.csv");
}

void testScaleSmoke() {
    // 100K vertices; tests 64-bit IDs, vector resizing, iterative algorithms and path length.
    const int n = 100000;
    AdjacencyList g;
    for (int i = 0; i < n; ++i) g.addVertex(9000000000LL + i, 27.95, -82.46);
    for (int i = 1; i < n; ++i) g.addEdge(9000000000LL + i - 1, 9000000000LL + i, 1);
    const auto stats = g.validate();
    check(stats.meets_size_target && stats.edges == static_cast<std::size_t>(n - 1),
          "100K scale validation incorrect");
    const auto d = dijkstra(g, 0, n - 1);
    const auto a = astar(g, 0, n - 1);
    check(d.distance_m == n - 1 && sameDistance(d, a), "100K scale shortest path incorrect");
    check(validatePath(g, 0, n - 1, d), "100K scale path reconstruction incorrect");
    check(d.hops() == static_cast<std::size_t>(n - 1), "100K scale hop count wrong");
}

}  // namespace

int main(int argc, char** argv) {
    try {
        testLoaderAndValidation();
        testCSVAndRollback();
        testHeuristicScale();
        testUnreachableAndSelf();
        testRandomizedIndependentOracle(false);
        testRandomizedIndependentOracle(true);
        testBenchmarkAndSCC();
        if (argc > 1 && std::string(argv[1]) == "--stress") testScaleSmoke();
        std::cout << "PASS: " << tests << " assertions"
                  << (argc > 1 ? " (including 100,000-vertex scale smoke test)" : "") << "\n";
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "FAILED assertion #" << tests << ": " << e.what() << "\n";
        return 1;
    }
}
