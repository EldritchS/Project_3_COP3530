"""Independent checks of the paired benchmark audit."""
import csv
import importlib.util
import pathlib
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('analyze_benchmark', ROOT/'scripts'/'analyze_benchmark.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)

COLS = ['query_id', 'src_id', 'dst_id', 'algorithm', 'reachable', 'distance_m', 'hops', 'expanded', 'median_ms', 'path_valid']

def example_records():
    return [
        ['0', '1', '2', 'dijkstra', '1', '8.00000000', '2', '5', '0.50000000', '1'],
        ['0', '1', '2', 'astar', '1', '8.00000000', '2', '3', '0.40000000', '1'],
        ['1', '2', '1', 'dijkstra', '0', '-1', '0', '7', '0.80000000', '1'],
        ['1', '2', '1', 'astar', '0', '-1', '0', '7', '0.60000000', '1'],
    ]

class AnalyzeTests(unittest.TestCase):
    def setUp(self):
        self.work = tempfile.TemporaryDirectory()
        self.addCleanup(self.work.cleanup)
        self.file = pathlib.Path(self.work.name)/'bench.csv'

    def write(self, records):
        with self.file.open('w', newline='') as f:
            out = csv.writer(f)
            out.writerow(COLS)
            out.writerows(records)

    def test_valid_pairs(self):
        self.write(example_records())
        result=mod.analyze(self.file)
        self.assertEqual(result['total_queries'], 2)
        self.assertEqual(result['unreachable_queries'], 1)
        self.assertEqual(result['algorithms']['dijkstra']['mean_expanded'], 6)
        self.assertEqual(result['algorithms']['astar']['mean_expanded'], 5)

    def test_missing_algorithm_rejected(self):
        self.write(example_records()[:-1])
        with self.assertRaisesRegex(ValueError,'Incomplete'):
            mod.analyze(self.file)

    def test_inconsistent_distance_rejected(self):
        rows=example_records();rows[1][5]='9'
        self.write(rows)
        with self.assertRaisesRegex(ValueError,'Distance disagreement'):
            mod.analyze(self.file)

    def test_invalid_path_rejected(self):
        rows=example_records();rows[1][9]='0'
        self.write(rows)
        with self.assertRaisesRegex(ValueError,'Invalid search'):
            mod.analyze(self.file)

    def test_bad_reachability_rejected(self):
        rows=example_records();rows[1][4]='0'
        self.write(rows)
        with self.assertRaisesRegex(ValueError,'Unreachable distance'):
            mod.analyze(self.file)

    def test_duplicate_rejected(self):
        rows=example_records();rows.append(rows[0][:]);self.write(rows)
        with self.assertRaisesRegex(ValueError,'Duplicate'):
            mod.analyze(self.file)

if __name__=='__main__':
    unittest.main()
