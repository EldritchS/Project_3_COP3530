# RouteBench: Dijkstra vs. A* on the Florida Road Network

**COP3530 Final Project · Team RouteBench (Group 3)** · Alexander Caro · Luana Navarro · Matthew Inkelaar

RouteBench loads a directed, weighted road graph of Florida (1,070,376 intersections and 2,712,798 road segments), finds shortest routes with **Dijkstra's algorithm** and **A\***, checks that both return the same distance and a valid path, and benchmarks them on 50 reproducible source–destination pairs.

## Requirements

- A C++14 compiler (g++, clang++ or Visual Studio) and CMake 3.10+ (or compile with g++ directly, see below)
- Python 3.8+ (standard library only) to download and convert the Florida data
- About 300 MB of free RAM and 200 MB of disk for the Florida graph

## Quick start: the whole Florida pipeline in one command

```bash
python3 scripts/run_pipeline.py
```

This downloads and verifies the Florida data, builds the program, runs every test, runs both 50-query benchmarks, audits the results and redraws the figure in `results/florida/`. It takes about 3 minutes. The steps below do the same things one at a time.

## 1. Build and test

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build --output-on-failure   # unit tests + Floyd–Warshall oracle
./build/routebench_tests --stress           # adds a 100,000-vertex scale test
python3 -m unittest discover -s tests -p 'test_*.py'
```

Without CMake:

```bash
g++ -std=c++14 -O2 main.cpp AdjacencyList.cpp Algorithms.cpp Dsort.cpp Asort.cpp Benchmark.cpp -o routebench
```

On Windows with Visual Studio's multi-config generator the program is `build\Release\routebench.exe`.

## 2. Get the Florida road network

```bash
python3 scripts/fetch_florida.py
```

This downloads the Florida graph from the 9th DIMACS Implementation Challenge (`USA-road-d.FLA`), falling back to a public GitHub mirror if the official server is unreachable, checks both files against SHA-256 digests, and writes:

- `data/florida/vertices.csv` — `vertex_id,latitude,longitude`
- `data/florida/edges.csv` — `src_id,dst_id,length_m`

The data is about 170 MB, so it is not committed to the repository.

## 3. Run the program

**Interactive menu:**

```bash
./build/routebench --vertices data/florida/vertices.csv --edges data/florida/edges.csv
```

Loading takes a few seconds and prints the vertex/edge counts and validation checks. Then use the menu:

| Option | Action |
|---|---|
| 1 | Load a different pair of CSV files |
| 2 / 3 | Set the source / destination vertex ID (Florida IDs are 1 to 1070376) |
| 4 / 5 | Run Dijkstra / A* (distance, hops, path, expanded vertices, time, path check) |
| 6 | Run both and check that the distances agree |
| 7 | Benchmark random queries (50 by default) and save a CSV |
| 8 | Show search history |
| 9 | Exit |

Example vertex IDs (nearest intersection to each place):

| Place | Vertex ID |
|---|---|
| University of Florida (Reitz Union), Gainesville | 11828 |
| Downtown Tampa | 343370 |
| Downtown Miami | 578831 |

For example, Gainesville → Tampa (11828 → 343370) is 203.4 km with 893 hops, and Tampa → Miami (343370 → 578831) is 389.2 km with 1,027 hops; both algorithms return the same distance.

**Batch benchmark (used for the report):**

```bash
./build/routebench --vertices data/florida/vertices.csv --edges data/florida/edges.csv \
  --batch --queries 50 --repeats 5 --seed 3530 --out results/florida/benchmark_safe.csv

./build/routebench --vertices data/florida/vertices.csv --edges data/florida/edges.csv \
  --batch --queries 50 --repeats 5 --seed 3530 --heuristic-scale 0.99 \
  --out results/florida/benchmark_c099.csv

python3 scripts/analyze_benchmark.py results/florida/benchmark_safe.csv \
  --output-dir results/florida/safe --label "Florida, provable c" --provenance "USA-road-d.FLA"
python3 scripts/make_figures.py results/florida/benchmark_safe.csv \
  results/florida/benchmark_c099.csv results/florida/figure_comparison.svg
```

Each benchmark row is `query_id, src_id, dst_id, algorithm, reachable, distance_m, hops, expanded, median_ms, path_valid`. Every query is run once untimed and then 5 timed times per algorithm; `median_ms` is the median of the 5. The program stops with an error if a path is invalid or if A* and Dijkstra disagree on any distance. Expanded-vertex counts are deterministic; times depend on the machine.

**Small demo graph** (12 vertices, includes unreachable pairs): use `data/demo_vertices.csv` and `data/demo_edges.csv` (IDs start at 5000000000).

## How it works

- **Graph:** adjacency list (`vector<vector<Edge>>`); 64-bit file IDs are mapped to compact indices with an `unordered_map`. Loading is all-or-nothing: a bad file leaves the current graph unchanged.
- **Validation:** missing endpoints, duplicate vertex IDs, bad coordinates, negative or non-numeric lengths, self-loops, parallel edges and a Florida bounding-box check.
- **Dijkstra and A\*:** one shared search with a lazy binary min-heap (`priority_queue`); stale heap entries are skipped. Dijkstra is the case h(v) = 0.
- **A\* heuristic:** h(v) = c × Haversine(v, target). While loading, the program computes c = the smallest ratio of edge length to straight-line distance (capped at 1). Every edge then satisfies length ≥ c × straight-line distance, so the heuristic is consistent and A\* always returns optimal routes. For Florida, c = 0.667929 because the DIMACS lengths are measured on a slightly smaller Earth model and rounded to 0.1 m. `--heuristic-scale` overrides c for experiments; results are still cross-checked against Dijkstra.
- **Query selection:** Kosaraju's algorithm (iterative) finds strongly connected components; reachable pairs come from the largest one, and when there are several components about 10% of queries are guaranteed-unreachable pairs from a sink component. The Florida graph is one component, so all 50 Florida queries are reachable.

## Files

| Path | Contents |
|---|---|
| `AdjacencyList.h/.cpp` | graph, CSV loading, ID compression, validation, heuristic scale |
| `Algorithms.h/.cpp`, `Dsort.cpp`, `Asort.cpp` | shared search, Dijkstra, A\*, path validation |
| `Benchmark.h/.cpp` | SCCs, query selection, timing, CSV export |
| `main.cpp` | interactive menu and batch mode |
| `scripts/` | one-command pipeline, data download/conversion, benchmark audit, figure |
| `tests/` | C++ and Python tests |
| `results/florida/` | benchmark CSVs, logs, summaries and figure used in the report |
| `Report_3_Old.pdf` | the team's original proposal |

## Data and license

Florida road network: 9th DIMACS Implementation Challenge — Shortest Paths (`USA-road-d.FLA`), derived from U.S. Census Bureau TIGER/Line data. Lengths in the source are in units of 0.1 m and are converted to meters.
