#include "AdjacencyList.h"

#include <algorithm>
#include <cmath>
#include <fstream>
#include <limits>
#include <sstream>
#include <stdexcept>
#include <unordered_set>

namespace routebench {
namespace {

constexpr double kEarthRadiusM = 6371008.8;
constexpr double kPi = 3.14159265358979323846;

std::string trim(const std::string& input) {
    const std::size_t first = input.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return "";
    const std::size_t last = input.find_last_not_of(" \t\r\n");
    return input.substr(first, last - first + 1);
}

std::vector<std::string> fields(const std::string& line) {
    // CSV schema uses only numeric fields and no quoted fields.
    std::vector<std::string> output;
    std::stringstream ss(line);
    std::string part;
    while (std::getline(ss, part, ',')) output.push_back(trim(part));
    if (!line.empty() && line.back() == ',') output.push_back("");
    return output;
}

std::int64_t parseId(const std::string& text) {
    std::size_t used = 0;
    std::int64_t id = std::stoll(text, &used);
    if (used != text.size()) throw std::invalid_argument("Invalid vertex ID: " + text);
    return id;
}

double parseDouble(const std::string& text) {
    std::size_t used = 0;
    double result = std::stod(text, &used);
    if (used != text.size() || !std::isfinite(result))
        throw std::invalid_argument("Invalid non-finite or malformed number: " + text);
    return result;
}

bool isHeader(const std::string& s, const std::string& first_field) {
    return s == first_field;
}

}  // namespace

double haversineMeters(double lat1, double lon1, double lat2, double lon2) {
    const double rad = kPi / 180.0;
    const double p1 = lat1 * rad;
    const double p2 = lat2 * rad;
    const double d_lat = (lat2 - lat1) * rad;
    const double d_lon = (lon2 - lon1) * rad;
    const double a = std::pow(std::sin(d_lat / 2.0), 2) +
                     std::cos(p1) * std::cos(p2) * std::pow(std::sin(d_lon / 2.0), 2);
    return 2.0 * kEarthRadiusM * std::asin(std::sqrt(std::min(1.0, std::max(0.0, a))));
}

void AdjacencyList::addVertex(std::int64_t id, double lat, double lon) {
    if (!std::isfinite(lat) || !std::isfinite(lon) || lat < -90 || lat > 90 ||
        lon < -180 || lon > 180)
        throw std::invalid_argument("Vertex has invalid coordinates: " + std::to_string(id));
    if (index_.find(id) != index_.end())
        throw std::invalid_argument("Duplicate vertex ID: " + std::to_string(id));
    if (vertices_.size() >= static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::overflow_error("Too many vertices for 32-bit internal indices");
    const int index = static_cast<int>(vertices_.size());
    vertices_.push_back({id, lat, lon});
    adjacency_.emplace_back();
    index_.emplace(id, index);
}

void AdjacencyList::addEdge(std::int64_t source_id, std::int64_t dest_id, double length_m) {
    const int source = find(source_id);
    const int dest = find(dest_id);
    if (source < 0 || dest < 0)
        throw std::invalid_argument("Edge refers to missing vertex: " +
                                    std::to_string(source_id) + " -> " + std::to_string(dest_id));
    if (!std::isfinite(length_m) || length_m < 0)
        throw std::invalid_argument("Edge has negative or non-finite distance");
    // A* needs h(u) <= length(u,v) + h(v) for every edge. With h = c * greatCircle and the
    // triangle inequality, that holds whenever length(u,v) >= c * greatCircle(u,v), so we
    // keep c equal to the smallest length / greatCircle ratio seen so far (never above 1).
    const double chord = straightLineDistance(source, dest);
    if (length_m < chord) {
        ++short_edges_;
        heuristic_scale_ = std::min(heuristic_scale_, length_m / chord);
    }
    adjacency_[source].push_back({dest, length_m});
    ++edges_count_;
}

void AdjacencyList::loadCSV(const std::string& vertices_path, const std::string& edges_path) {
    // Strong exception safety: leave the original graph unchanged if either file is bad.
    AdjacencyList candidate;
    {
        std::ifstream input(vertices_path);
        if (!input) throw std::runtime_error("Cannot open vertex file: " + vertices_path);
        std::string line;
        std::size_t number = 0;
        while (std::getline(input, line)) {
            ++number;
            if (trim(line).empty()) continue;
            try {
                const auto f = fields(line);
                if (number == 1 && !f.empty() && isHeader(f[0], "vertex_id")) continue;
                if (f.size() != 3) throw std::invalid_argument("Expected 3 CSV fields");
                candidate.addVertex(parseId(f[0]), parseDouble(f[1]), parseDouble(f[2]));
            } catch (const std::exception& e) {
                throw std::runtime_error(vertices_path + ":" + std::to_string(number) + ": " + e.what());
            }
        }
        if (!input.eof() && input.fail()) throw std::runtime_error("Error reading: " + vertices_path);
    }
    if (candidate.vertexCount() == 0) throw std::invalid_argument("Vertex file is empty");
    {
        std::ifstream input(edges_path);
        if (!input) throw std::runtime_error("Cannot open edge file: " + edges_path);
        std::string line;
        std::size_t number = 0;
        while (std::getline(input, line)) {
            ++number;
            if (trim(line).empty()) continue;
            try {
                const auto f = fields(line);
                if (number == 1 && !f.empty() && isHeader(f[0], "src_id")) continue;
                if (f.size() != 3) throw std::invalid_argument("Expected 3 CSV fields");
                candidate.addEdge(parseId(f[0]), parseId(f[1]), parseDouble(f[2]));
            } catch (const std::exception& e) {
                throw std::runtime_error(edges_path + ":" + std::to_string(number) + ": " + e.what());
            }
        }
        if (!input.eof() && input.fail()) throw std::runtime_error("Error reading: " + edges_path);
    }
    *this = std::move(candidate);
}

void AdjacencyList::overrideHeuristicScale(double scale) {
    if (!std::isfinite(scale) || scale <= 0 || scale > 1)
        throw std::invalid_argument("Heuristic scale must be in (0, 1]");
    heuristic_scale_ = scale;
    scale_overridden_ = true;
}

int AdjacencyList::find(std::int64_t id) const {
    const auto found = index_.find(id);
    return found == index_.end() ? -1 : found->second;
}

const Vertex& AdjacencyList::vertex(int internal_id) const {
    return vertices_.at(static_cast<std::size_t>(internal_id));
}

const std::vector<Edge>& AdjacencyList::neighbors(int internal_id) const {
    return adjacency_.at(static_cast<std::size_t>(internal_id));
}

double AdjacencyList::straightLineDistance(int from, int to) const {
    const Vertex& a = vertex(from);
    const Vertex& b = vertex(to);
    return haversineMeters(a.latitude, a.longitude, b.latitude, b.longitude);
}

ValidationStats AdjacencyList::validate(bool require_florida_bounds) const {
    ValidationStats stats;
    stats.vertices = vertexCount();
    stats.edges = edgeCount();
    stats.meets_size_target = stats.vertices >= 100000;
    std::unordered_set<std::uint64_t> seen;
    seen.reserve(edges_count_);
    std::size_t counted = 0;
    for (std::size_t i = 0; i < vertices_.size(); ++i) {
        const auto& v = vertices_[i];
        if (!(std::isfinite(v.latitude) && std::isfinite(v.longitude)))
            throw std::logic_error("Invalid stored vertex coordinates");
        if (v.latitude < 24.0 || v.latitude > 31.2 || v.longitude < -88.1 || v.longitude > -79.7)
            stats.florida_bounds_ok = false;
        for (const auto& edge : adjacency_[i]) {
            if (edge.to < 0 || static_cast<std::size_t>(edge.to) >= vertices_.size())
                throw std::logic_error("Invalid internal edge target");
            if (!std::isfinite(edge.length_m) || edge.length_m < 0)
                throw std::logic_error("Invalid stored edge weight");
            const double chord = straightLineDistance(static_cast<int>(i), edge.to);
            if (edge.length_m < chord) ++stats.edges_shorter_than_great_circle;
            if (edge.length_m < chord && chord > 0)
                stats.heuristic_scale = std::min(stats.heuristic_scale, edge.length_m / chord);
            if (edge.to == static_cast<int>(i)) ++stats.self_loops;
            const auto packed = (static_cast<std::uint64_t>(i) << 32) |
                                static_cast<std::uint32_t>(edge.to);
            if (!seen.insert(packed).second) ++stats.parallel_directed_edges;
            ++counted;
        }
    }
    if (counted != edges_count_) throw std::logic_error("Edge count mismatch");
    if (stats.edges_shorter_than_great_circle != short_edges_)
        throw std::logic_error("Short-edge count mismatch");
    // Recomputed independently of addEdge; the two must agree unless overridden for an experiment.
    if (stats.heuristic_scale != heuristic_scale_ && !scale_overridden_)
        throw std::logic_error("Heuristic scale bookkeeping mismatch");
    if (require_florida_bounds && !stats.florida_bounds_ok)
        throw std::invalid_argument("One or more vertices lie outside the broad Florida bounding box");
    return stats;
}

}  // namespace routebench
